import React from "react";
import "./css/pizza.css";

function Pizza() {
  return (
    <div className="Pizza">
      <h1 className="header-text">Beanie's Dollar Pizza</h1>
    </div>
  );
}

export default Pizza;
