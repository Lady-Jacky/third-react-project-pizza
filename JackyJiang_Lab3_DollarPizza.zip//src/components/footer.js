import "./css/footer.css";

function Footer() {
  phoneNum = "(212) 555 5555";
  return (
    <div className="info">
      <div>Address: 555 Time Square, NY, NY 10000</div>
      <div>Phone Number: {phoneNum}</div>
    </div>
  );
}

export default Footer;
